export default interface IPurchase {
    _id: object,
    email: string,
    bookId: object,
    purchaseDate: Date,
    price: number,
    title: string,
    author: string,
}