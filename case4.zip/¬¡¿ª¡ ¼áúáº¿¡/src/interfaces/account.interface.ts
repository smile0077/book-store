export default interface IAccountInfo {
    role: string;
    balance: number;
}