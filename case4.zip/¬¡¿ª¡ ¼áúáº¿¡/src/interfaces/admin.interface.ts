export default interface IAdmin {
    _id: object,
    name: string,
    email: string,
    password: string,
    role: string,
    balance: string,
}